package com.meeting_site_project.YM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YmApplicationTests {

	@Test
	void contextLoads() {
	}

}
