package com.meeting_site_project.YM.repository;

@org.springframework.stereotype.Repository
public interface Repository {

}
