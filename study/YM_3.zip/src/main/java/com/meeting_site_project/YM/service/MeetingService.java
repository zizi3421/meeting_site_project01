package com.meeting_site_project.YM.service;

import com.meeting_site_project.YM.repository.MybatisRepository;
import com.meeting_site_project.YM.vo.GroupInfo;
import com.meeting_site_project.YM.vo.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MeetingService {


//    MybatisRepository mybatisRepository;
//
//    @Autowired
//    public MeetingService(MybatisRepository mybatisRepository) {
//        this.mybatisRepository = mybatisRepository;
//    }
//
//    public void insertFirstMeeting(GroupInfo groupInfo) {
//        mybatisRepository.insertFirstMeeting(groupInfo);
//    }
//
//    public GroupInfo selectByMeeting(int meeting) {
//        return mybatisRepository.selectByMeeting(meeting);
//    }

}
